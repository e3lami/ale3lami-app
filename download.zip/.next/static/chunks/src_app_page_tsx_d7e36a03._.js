(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_674e5588._.js",
  "static/chunks/node_modules_213d37ce._.js"
],
    source: "dynamic"
});
