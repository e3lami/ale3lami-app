(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_750dd7e2._.js",
  "static/chunks/src_9eb9d5bd._.js"
],
    source: "dynamic"
});
