(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_892f3b92._.js",
  "static/chunks/src_12ec0774._.js",
  "static/chunks/src_components_home_breaking-news-ticker_495a87f3.css"
],
    source: "dynamic"
});
