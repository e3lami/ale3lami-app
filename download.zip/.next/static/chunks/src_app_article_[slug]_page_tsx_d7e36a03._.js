(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_e0b5fcb8._.js",
  "static/chunks/node_modules_4b04ffb5._.js"
],
    source: "dynamic"
});
