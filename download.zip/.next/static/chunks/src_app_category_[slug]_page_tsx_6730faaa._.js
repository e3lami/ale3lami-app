(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_816f1733._.js",
  "static/chunks/src_4046ea7a._.js"
],
    source: "dynamic"
});
