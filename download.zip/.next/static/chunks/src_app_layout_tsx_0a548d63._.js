(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_91e4631d.css",
  "static/chunks/node_modules_3b3fbf6d._.js",
  "static/chunks/src_e9655656._.js"
],
    source: "dynamic"
});
