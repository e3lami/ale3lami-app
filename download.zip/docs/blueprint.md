# **App Name**: Al-E3lami News Hub

## Core Features:

- Category Feed Display: Display posts fetched from the WordPress REST API, divided into 'السياسية' (Politics), 'متفرقات' (Miscellaneous), and 'أقلام' (Opinions/Pens) categories, with RTL support for Arabic.
- Article View: Display the full content of a selected news article.
- Text-to-Speech: Read article content aloud when a button is clicked.
- Push Notifications: Send push notifications for breaking news and top stories using Firebase.

## Style Guidelines:

- Primary color: A muted blue (#6699CC) evoking trust and stability, complementing the serious nature of news content.
- Background color: Light gray (#F0F0F0), a desaturated near-tone of the primary hue that provides a clean and neutral backdrop for content.
- Accent color: A subtle green (#8FBC8F), placed to the 'left' on the color wheel relative to the blue, provides visual contrast without disrupting the calm aesthetic.
- Body and headline font: 'PT Sans', a modern, warm, and readable sans-serif, suitable for both headlines and body text in Arabic.
- Use clear, simple icons that are easily understood, reflecting the information they represent, and follow Material Design 3 guidelines.
- Employ a modern Material 3 design with a clean and intuitive UI, optimized for RTL (Arabic) reading, emphasizing readability and ease of navigation.
- Incorporate subtle animations, such as smooth transitions between screens, to enhance the user experience without being distracting.