'use server';

// This file is no longer used.
// All server-side translation logic has been removed.
