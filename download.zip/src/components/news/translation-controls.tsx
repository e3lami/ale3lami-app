'use client';

// This component is no longer used.
// All translation functionality has been removed as per user request.
export default function TranslationControls() {
  return null;
}
