'use client';

// This component is no longer used.
// All Text-to-Speech functionality has been removed as per user request.
export default function TextToSpeechButton() {
  return null;
}
